package com.example.todo;

import android.annotation.SuppressLint;
import android.os.FileUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<String> items;
    Button button4;
    EditText edittx;
    RecyclerView edittxt;
    new_adapter itemsAdapter;



    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button4 = findViewById(R.id.button4);
        edittx = findViewById(R.id.edittxt);
        edittxt = findViewById(R.id.edtot);


        items = new ArrayList<>();
        items.add("Buy Milk");
        items.add("Go to the gym");
        items.add("Have fun!");

        new_adapter.OnLongClickListener onLongClickListener = new new_adapter.OnLongClickListener() {

            @Override
            public void OnItemLongClicked(int position) {
                // delete the item long pressed
                items.remove(position);
                //notify the adapter
                itemsAdapter.notifyItemRemoved(position);
                Toast.makeText(getApplicationContext(), "item was added", Toast.LENGTH_SHORT).show();

            }
        };
        itemsAdapter = new new_adapter(items, onLongClickListener);
        edittxt.setAdapter(itemsAdapter);
        edittxt.setLayoutManager(new LinearLayoutManager(this));

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String todoitem = edittx.getText().toString();
                //add item to the model
                items.add(todoitem);
                //notify adapter that an item is inserted
                itemsAdapter.notifyItemInserted(items.size() - 1);
                edittx.setText("");
                Toast.makeText(getApplicationContext(), "item was added", Toast.LENGTH_SHORT).show();


            }
        });

    }




    private File getDataFile() {
        return new File(getFilesDir(),  "data.txt");
        }
        // This function will load items by reading every line of the data file
        private void loadItems(){
        items = new ArrayList<>(FileUtils.readLines(getDataFile(), Charset.defaultCharset()));
        }
        // this function saves items by writing them into the data
    }
